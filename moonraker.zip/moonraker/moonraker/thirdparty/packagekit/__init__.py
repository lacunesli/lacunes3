# package definition for packagekit thirdparty files
