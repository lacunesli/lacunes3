# mkdocs build --clean --site-dir _html --config-file mkdocs.yml
# For testing is better to use the integrated server.
mkdocs serve --config-file mkdocs.yml
